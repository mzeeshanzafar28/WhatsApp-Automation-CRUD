<?php

$conn = mysqli_connect('localhost','root','','whatsapp') or die("Connection Failed");

?>