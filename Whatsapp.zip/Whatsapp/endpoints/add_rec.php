<?php
require_once( '../config.php' );
header( 'Content-Type: application/json' );

if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
    $phone_no = isset( $_POST[ 'phone_no' ] ) ? $_POST[ 'phone_no' ] : '';
    $msg = isset( $_POST[ 'msg' ] ) ? $_POST[ 'msg' ] : '';
    $type = isset( $_POST[ 'type' ] ) ? $_POST[ 'type' ] : '';
    $data = isset( $_POST[ 'data' ] ) ? $_POST[ 'data' ] : '';

    if ( !empty( $phone_no ) && !empty( $msg ) && !empty( $type ) && !empty( $data ) ) {
        $phone_no = mysqli_real_escape_string( $conn, $phone_no );
        $msg = mysqli_real_escape_string( $conn, $msg );
        $type = mysqli_real_escape_string( $conn, $type );
        $data = mysqli_real_escape_string( $conn, $data );

        $query = "INSERT INTO sms (phone_no, msg, type, data) VALUES ('$phone_no', '$msg', '$type', '$data')";
        $result = mysqli_query( $conn, $query );

        if ( $result ) {
            echo json_encode( [ 'status' => 'success', 'message' => 'Data inserted successfully' ] );
        } else {
            echo json_encode( [ 'status' => 'error', 'message' => 'Failed to insert data' ] );
        }
    } else {
        echo json_encode( [ 'status' => 'error', 'message' => 'Phone number, message, type, and data are required' ] );
    }
} else {
    echo json_encode( [ 'status' => 'error', 'message' => 'Invalid request method' ] );
}
?>
