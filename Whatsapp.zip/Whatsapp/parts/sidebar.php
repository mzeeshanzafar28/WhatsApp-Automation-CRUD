<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item">
        <a class="nav-link " href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="view_pending.php">
          <i class="bi bi-grid"></i>
          <span>List Pending</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="add_data.php">
          <i class="bi bi-grid"></i>
          <span>Add Data</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="view_sent.php">
          <i class="bi bi-grid"></i>
          <span>Sent Details</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="add_bulk_data.php">
          <i class="bi bi-grid"></i>
          <span>Add Bulk Data</span>
        </a>
      </li>

    </ul>

  </aside>